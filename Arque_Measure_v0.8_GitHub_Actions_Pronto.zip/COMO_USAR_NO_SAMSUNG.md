# Arque Measure — compilação GitHub Actions

Este pacote é o projeto Android v0.8 configurado para compilar na nuvem. **Não contém APK e não foi validado num aparelho físico.**

1. Conecte GitHub ao ChatGPT e autorize acesso ao repositório desejado, ou envie os arquivos para a raiz de um repositório GitHub novo.
2. Na aba **Actions** do repositório, abra **Gerar APK Arque Measure**.
3. Toque em **Run workflow**. A compilação também é disparada ao enviar arquivos para `main`.
4. Se a execução ficar verde, abra-a e baixe o artefato **Arque-Measure-v0.8-APK**.
5. Extraia o ZIP do artefato no Samsung e instale `app-debug.apk`.

**Se a execução falhar:** abra o log da etapa "Compilar APK de teste". O erro precisa ser corrigido antes de prometer um APK funcional.

O APK debug serve apenas para testes e não equivale a uma versão pronta para medição profissional. Teste câmera, armazenamento, Bluetooth, permissões, S Pen e transferência local em aparelhos reais.
